# Uso en Overleaf

1. Cree un proyecto vacío en Overleaf.
2. Suba `main.tex` o cargue directamente el ZIP entregado.
3. Seleccione **pdfLaTeX** como compilador.
4. Edite las variables ubicadas al inicio de `main.tex`:
   - `\TeamName`
   - `\TeamMembers`
   - `\TeamEntity`
   - `\ContactEmail`
   - URL del repositorio y del dashboard
5. Compile dos veces para actualizar el índice, las referencias cruzadas y el total de páginas.

## Estado del contenido

La formulación, fuentes, metodología, auditoría, integración, reproducibilidad, ética, limitaciones y glosario están completos con la evidencia disponible.

Las secciones de resultados y recomendaciones están marcadas como pendientes. Deben actualizarse únicamente después de validar el análisis y el dashboard.

## Archivos que conviene añadir después

- Captura o exportación del mapa principal.
- Gráfico del hallazgo principal.
- Enlace final al repositorio.
- Enlace final al dashboard.
- Nombres y roles del equipo.
